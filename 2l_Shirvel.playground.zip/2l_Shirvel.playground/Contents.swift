import Foundation


print("Задание №1. Написать функцию, которая определяет, четное число или нет.\n")
let number: Int = 18

func avenOrOdd(numbers: Int) -> Bool {
    if numbers % 2 == 0 {
        return true
    } else {
        return false
    }
}

avenOrOdd(numbers: number)
print("--------------------------------------\n")

print("Задание №2. Написать функцию, которая определяет, четное число или нет.\n")
func devidedBy3(numbers: Int) -> Bool {
    if numbers % 3 == 0 {
        return true
    } else {
        return false
    }
}

devidedBy3(numbers: number)
print("--------------------------------------\n")

print("Задание №3. Создать возрастающий массив из 100 чисел.\n")
var arrayOf100 = [Int]()

for i in 0...100 {
    if i <= 100 {
        arrayOf100.append(i)
    }
}

print(arrayOf100)
print("--------------------------------------\n")

print("Задание №4. Удалить из этого массива все четные числа и все числа, которые не делятся на 3.\n")

func filteringArray(evenNumbers: Int, oddNumbers: Int, completeNewArray: inout [Int]) {
    for i in stride(from: completeNewArray.count - 1, through: 0, by: -1) {
        if completeNewArray[i] % evenNumbers == 0 {
            completeNewArray.remove(at: i)
        } else if completeNewArray[i] % oddNumbers != 0 {
                completeNewArray.remove(at: i)
            }
        }
    }

filteringArray(evenNumbers: 2, oddNumbers: 3, completeNewArray: &arrayOf100)
print(arrayOf100)

print("--------------------------------------\n")

print("Задание №5. Написать функцию, которая добавляет в массив новое число Фибоначчи, и добавить при помощи нее 100 элементов.\n")

func fiboArray(_ n: Int) -> [Double] {
    var fibonacci: [Double] = [1, 1]
    for i in (2...n) {
        fibonacci.append(fibonacci[i - 1] + fibonacci[i - 2])
    }
    return fibonacci
}
print("Массив чисел Фибоначчи:\n\(fiboArray(100))")

print("--------------------------------------\n")

print("Задание №6. Заполнить массив из 100 элементов различными простыми числами. \n")





/*
 6. * Заполнить массив из 100 элементов различными простыми числами. Натуральное число, большее единицы, называется простым, если оно делится только на себя и на единицу. Для нахождения всех простых чисел не больше заданного числа n, следуя методу Эратосфена, нужно выполнить следующие шаги:
 a. Выписать подряд все целые числа от двух до n (2, 3, 4, ..., n).
 b. Пусть переменная p изначально равна двум — первому простому числу.
 c. Зачеркнуть в списке числа от 2p до n, считая шагами по p (это будут числа, кратные p: 2p, 3p, 4p, ...).
 d. Найти первое не зачёркнутое число в списке, большее, чем p, и присвоить значению переменной p это число.
 e. Повторять шаги c и d, пока возможно.
 */
