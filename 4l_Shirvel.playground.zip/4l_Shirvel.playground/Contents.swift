import UIKit

enum Brand: String{
    case mersedes, toyota, ford
}

enum Model: String{
    case s63AMG, e63S, mustang, GT, celica, supra, vito, transit, hiase
}

enum CarActions {
    case engineOn, engineOff, windowsOpen, windowsClose
    case instalSpoiler, deliteSpoiler
    case trunkLoad, trunkUnLoad
    
}

class Car {
    var yearOfIssue: Int // - где нет значений, нужно прописать в конструкторе
    var brand: Brand
    var model: Model
    var color: UIColor
    var enjineStatus: Bool = false
    var windowsCondition: Bool = false
    
    // --------------- создаем конструктор для обозначения переменных ---------------
    
    init( yearOfIssue: Int, brand: Brand, model: Model, color: UIColor) {
        self.yearOfIssue = yearOfIssue
        self.brand = brand
        self.model = model
        self.color = color
    }
    
    // --------------- создаем функцию (метод) для выполнения действий ---------------
    
    func changeCondition(action: CarActions) {
        
        switch action {
        case .engineOn:
            guard !enjineStatus else { print("Ошибка, двигатель уже запущен"); return} // - мы проверяем, если двигатель уже запущен (turnEnjine = false), то мы попадаем в else и выводим сообщение и выходим, если turnEnjine = true, то идем дальше и включаем двигатель
            enjineStatus = true
            print("Двигатель запущен")
            
        case .engineOff:
            guard enjineStatus else { print("Ошибка, двигатель уже выключен"); return}
            enjineStatus = false
            print("Двигатель выключен")
            
        case .windowsOpen:
            guard !windowsCondition else { print("Ошибка, окна уже открыты"); return}
            windowsCondition = true
            print("Окна открыты")
            
        case .windowsClose:
            guard !windowsCondition else { print("Ошибка, окна уже закрыты"); return}
            windowsCondition = false
            print("Окна закрыты")
            
        default:
            print("----------------------")
            return
        }
    }
}

class SportСar: Car {
    let maxSpeed: Double = 360.0
    let timeTo100: Double = 3.0
    var spoilerStatus: Bool = false
    
    override func changeCondition(action: CarActions) {
        super.changeCondition(action: action)
        switch action {
        case .instalSpoiler:
            guard !spoilerStatus else { print("Ошибка, спойлер уже установлен"); return}
            spoilerStatus = true
            print("Спойлер установлен")
            
        case .deliteSpoiler:
            guard spoilerStatus else { print("Ошибка, спойлер нет"); return}
            spoilerStatus = true
            print("Спойлер удален")
            
        default:
            print("Дейсвтия не поддерживаются спорт каром")
            return
        }
    }
}

class TruckСar: Car {
    var maxCapacity: Int
    var trankCondition: Int = 0
    var weight: Int = 0
    
    init(yearOfIssue: Int, brand: Brand, model: Model, color: UIColor, trankCondition: Int, maxCapacity: Int, weight: Int) {
        self.maxCapacity = maxCapacity
        self.trankCondition = trankCondition
        self.weight = weight
        super.init(yearOfIssue: yearOfIssue, brand: brand, model: model, color: color)
    }
    
    override func changeCondition(action: CarActions) {
        super.changeCondition(action: action)
        switch action {
        case .trunkLoad:
            if maxCapacity < trankCondition + weight {
                print("Не возможно положить, в багажнике осталось всего \(maxCapacity - trankCondition) объема.")
            } else {
                trankCondition += weight
                print("Положили в багажник еще \(weight) объема")
            }
            
        case .trunkUnLoad:
            if trankCondition - weight < 0 {
                print("Не возможно достать вещи, в багажнике всего \(trankCondition) объема.")
            } else {
                let newConditionTrunk = trankCondition - weight
                print("Достали из багажника \(weight) объема, осталось в багажнике всего \(newConditionTrunk) объема.")
            }
            
        default:
            print("-------------------")
            return
        }
    }
}

var sc = SportСar(yearOfIssue: 2000, brand: .mersedes, model: .e63S, color: .black)
var tc = TruckСar(yearOfIssue: 2010, brand: .ford, model: .transit, color: .brown, trankCondition: 100, maxCapacity: 800, weight: 400)

tc.changeCondition(action: .trunkLoad)
sc.changeCondition(action: .instalSpoiler)

print("Свободное место в багажнике \(tc.brand) \(tc.model) \(tc.yearOfIssue) года выпуска: \(tc.maxCapacity - tc.trankCondition) из \(tc.maxCapacity)")
print("На \(sc.brand) \(sc.model) \(sc.yearOfIssue) установлен спортивный спойлер: \(sc.spoilerStatus)")



/*
 ---------- Пытался сделать так, чтобы суммы груза можно было вводить запросе данного действия, но не получилось --------
 ---------------------------------- Вот как я это делал, может подскажешь почему не пошло ---------------
 ------------ И еще почему-то особенные эелементы каждой разных машин, почему-то видны и другим машинам, не смог разобраться опчему -----------------------------
 
 enum CarActions {
 case instalSpoiler, deliteSpoiler
 case trunkLoad(weight: Int), trunkUnLoad(weight: Int)
 
 }
 
 class TruckСar {
 var maxCapacity: Int
 var trankCondition: Int = 0
 var weight: Int
 
 init(maxCapacity: Int, trankCondition: Int, weight: Int) {
 self.maxCapacity = maxCapacity
 self.trankCondition = trankCondition
 self.weight = weight
 
 }
 
 func changeCondition(action: CarActions) {
 switch action {
 case .trunkLoad (weight):
 if maxCapacity < trankCondition + weight {
 print("Не возможно положить, в багажнике осталось всего \(maxCapacity - trankCondition) объема.")
 } else {
 trankCondition += weight
 print("Положили в багажник еще \(weight) объема")
 }
 
 case .trunkUnLoad (weight):
 if trankCondition - weight < 0 {
 print("Не возможно достать вещи, в багажнике всего \(trankCondition) объема.")
 } else {
 let newConditionTrunk = trankCondition - weight
 print("Достали из багажника \(weight) объема, осталось в багажнике всего \(newConditionTrunk) объема.")
 }
 
 default:
 print("Не поддерживаемое действие")
 return
 }
 }
 }
 
 var tc = TruckСar(maxCapacity: 300, trankCondition: 10, weight: 200)
 tc.changeCondition(action: .trunkLoad(weight: 300))
 
 
 */
