import UIKit

enum Brand: String{
    case mersedes, toyota, ford
}

enum Model: String{
    case s63AMG, e63S, mustang, GT, celica, supra, vito, transit, hiase
}

enum CarActions {
    case engineOn, engineOff, windowsOpen, windowsClose
    case instalSpoiler, deliteSpoiler
    case trunkLoad, trunkUnLoad
    
}

protocol Car {
    var yearOfIssue: Int { get set }
    var color: UIColor { get set }
    var enjineStatus: Bool { get set }
    var windowsCondition: Bool { get set }
    var brand: Brand { get set }
    var model: Model { get set }
    
    func changeCondition(action: CarActions)
}

extension Car {
    mutating func changeCondition(action: CarActions) {      // - добавляем mutating
        
        switch action {
        case .engineOn:
            guard !enjineStatus else { print("Ошибка, двигатель уже запущен"); return} // - мы проверяем, если двигатель уже запущен (turnEnjine = false), то мы попадаем в else и выводим сообщение и выходим, если turnEnjine = true, то идем дальше и включаем двигатель
            enjineStatus = true
            print("Двигатель запущен")
            
        case .engineOff:
            guard enjineStatus else { print("Ошибка, двигатель уже выключен"); return}
            enjineStatus = false
            print("Двигатель выключен")
            
        case .windowsOpen:
            guard !windowsCondition else { print("Ошибка, окна уже открыты"); return}
            windowsCondition = true
            print("Окна открыты")
            
        case .windowsClose:
            guard !windowsCondition else { print("Ошибка, окна уже закрыты"); return}
            windowsCondition = false
            print("Окна закрыты")
            
        default:
            print("----------------------")
            return
        }
    }
}

class SportСar: Car {
    var yearOfIssue: Int = 2017
    var color: UIColor = .black
    var enjineStatus: Bool = false
    var windowsCondition: Bool = false
    var brand: Brand = .mersedes
    var model: Model = .e63S
    var spoilerStatus: Bool = false
    
    func changeCondition(action: CarActions) {
        switch action {
        case .instalSpoiler:
            guard !spoilerStatus else { print("Ошибка, спойлер уже установлен"); return}
            spoilerStatus = true
            print("Спойлер установлен")
            
        case .deliteSpoiler:
            guard spoilerStatus else { print("Ошибка, спойлер нет"); return}
            spoilerStatus = true
            print("Спойлер удален")
            
        default:
            print("Дейсвтия не поддерживаются спорт каром")
            return
        }
    }
}

extension SportСar: CustomStringConvertible {
    var description: String {
        return "Спортивный автомобиль \(brand) \(model) \(yearOfIssue) года выпуска"
    }
}

class TruckСar: Car {
    var yearOfIssue: Int
    var color: UIColor
    var enjineStatus: Bool = false
    var windowsCondition: Bool = false
    var brand: Brand = .ford
    var model: Model = .transit
    var maxCapacity: Int
    var trankCondition: Int = 0
    var weight: Int = 0
    
    init(yearOfIssue: Int, color: UIColor, trankCondition: Int, maxCapacity: Int, weight: Int) {
        self.yearOfIssue = yearOfIssue
        self.color = color
        self.trankCondition = trankCondition
        self.weight = weight
        self.maxCapacity = maxCapacity
    }
    
    func changeCondition(action: CarActions) {
        switch action {
        case .trunkLoad:
            if maxCapacity < trankCondition + weight {
                print("Не возможно положить, в багажнике осталось всего \(maxCapacity - trankCondition) объема.")
            } else {
                trankCondition += weight
                print("Положили в багажник еще \(weight) объема")
            }
            
        case .trunkUnLoad:
            if trankCondition - weight < 0 {
                print("Не возможно достать вещи, в багажнике всего \(trankCondition) объема.")
            } else {
                let newConditionTrunk = trankCondition - weight
                print("Достали из багажника \(weight) объема, осталось в багажнике всего \(newConditionTrunk) объема.")
            }
            
        default:
            print("-------------------")
            return
        }
    }
}

extension TruckСar: CustomStringConvertible {
    var description: String {
        return "Грузовой автомобиль \(brand) \(model) \(yearOfIssue) года выпуска"
    }
}


let sportCar = SportСar()
sportCar.changeCondition(action: .instalSpoiler)
print(sportCar)
print("--------------------------------")

let truckCar = TruckСar(yearOfIssue: 2000, color: .red, trankCondition: 100, maxCapacity: 800, weight: 400)
truckCar.changeCondition(action: .trunkLoad)
print(truckCar)
print("--------------------------------")
