import UIKit

/*
 1. Реализовать свой тип коллекции «очередь» (queue) c использованием дженериков.
 2. Добавить ему несколько методов высшего порядка, полезных для этой коллекции (пример: filter для массивов)
 3. * Добавить свой subscript, который будет возвращать nil в случае обращения к несуществующему индексу.
 */

struct Queue<T> {
    private var array = [T]()
    
    mutating func enqueue(_ number: T) {
        array.append(number)
    }
    
    mutating func dequeue() -> T? {
        guard array.count > 0 else { return nil }
        return array.removeLast()
    }
    
    func check(_ terms: (T) -> Bool ) -> [T] {
        var result = [T]()
        for i in array {
            if terms(i) {
                result.append(i)
            }
        }
        return result
    }
    
    subscript(element: Int) -> T? {
        guard element < array.count else { return nil}
        return array[element]
    }
}

var queue = Queue<Int>()
queue.enqueue(1)
queue.enqueue(2)
queue.enqueue(3)
queue.enqueue(4)
queue.enqueue(5)
queue.enqueue(6)
queue.enqueue(7)

print(queue)
